package com.perscholas.java_basics;

public class HomeClass {

	public static void main(String[] args) {
		
		addIntegers();
		addDouble();
		addDoubleAndInteger();
		divideIntegers();
		divideDoubles();
		convertIntegers();
		addNames();
		createOrder();
	}
	
	public static void addIntegers() {
		int num1 = 5;
		int num2 = 7;
		int result = num1 + num2;
		
		System.out.println("Bullet 1 Results: " + result);
	}
	public static void addDouble() {
		double num1 = 10;
		double num2 = 123;
		double result = num1 + num2;
		
		System.out.println("Bullet 2 Results: " + result);
	}
	public static void addDoubleAndInteger() {
		double num1 = 8.5;
		int num2 = 10;
		double result = num1 + num2;
		
		System.out.println("Bullet 3 Results: " + result);
	}
	public static void divideIntegers() {
		double num1 = 20.5;
		int num2 = 10;
		double result = num1 / num2;
		
		System.out.println("Bullet 4 Results: " + result);
	}
	public static void divideDoubles() {
		double num1 = 10.25;
		double num2 = 3.5;
		double result = num1 / num2;
		
		System.out.println("Bullet 5a Results: " + result);
		
		result = (int) result;
		
		System.out.println("Bullet 5b Results: " + result);
	}
	public static void convertIntegers() {
		int x = 5;
		int y = 6;
		double q = y/x;
		
		System.out.println("Bullet 6a Results: " + q);
		
		q = (double) y;
		
		System.out.println("Bullet 6b Results: " + q);
		
	}
	public static void addNames() {
		final String FIRST_NAME = "Becky";
		
		System.out.println("Bullet 7 Results: " + FIRST_NAME);
	}
	public static void createOrder() {
		double coffee = 3.25;
		double espresso = 5.25;
		double green_tea = 1.50;
		
		double subtotal = 0;
		double totalSale = 0;
		
		subtotal = (3 * coffee) + (4 * espresso) + (2 * green_tea);
		
		final double SALES_TAX = 1.50;
		
		totalSale = SALES_TAX + subtotal;
		System.out.println("Bullet 8 Results: " + totalSale);
	}

}
